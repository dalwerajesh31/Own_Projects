fetch('https://hindi-jokes-api.onrender.com/jokes?api_key=f5dd44f70663d01ca0c63c8eb762')
    .then(data => data.json())
    .then(jokeData => {
        const joketxt = jokeData.jokeContent;
        const jokeEle = document.getElementById('jokeEle');

        jokeEle.innerHTML = joketxt;
    })

    // https://hindi-jokes-api.onrender.com/jokes?api_key=f5dd44f70663d01ca0c63c8eb762

    // https://icanhazdadjoke.com/slack